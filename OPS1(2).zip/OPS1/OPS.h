#ifndef OPS_H
#define OPS_H

#include <QWidget>
#include <QStringListModel>
#include "Queue.h"
#include "Stack.h"

QT_BEGIN_NAMESPACE
namespace Ui { class Form; }  
QT_END_NAMESPACE

class OPS : public QWidget
{
    Q_OBJECT

public:
    explicit OPS(QWidget *parent = nullptr);
    ~OPS();

private slots:
    void onPushClicked();
    void onPopClicked();
    void onPeekStackClicked();
    void onEnqueueClicked();
    void onDequeueClicked();
    void onPeekQueueClicked();

private:
    Ui::Form *ui; 
    Stack orderStack;
    Queue orderQueue;
    QStringListModel *queueModel;
    QStringListModel *stackModel;

    void updateQueueView();
    void updateStackView();
};

#endif // OPS_H
