#ifndef QUEUE_H
#define QUEUE_H

#include <queue>
using namespace std;

class Queue {
private:
    queue<int> queueArray;

public:
    void enqueue(int value) { queueArray.push(value); }
    void dequeue() { if (!queueArray.empty()) queueArray.pop(); }
    int peek() const { return queueArray.empty() ? -1 : queueArray.front(); }
    queue<int> getQueue() const { return queueArray; } 
};


#endif
