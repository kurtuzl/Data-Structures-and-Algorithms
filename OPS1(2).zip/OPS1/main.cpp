#include <QApplication>
#include "OPS.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    OPS mainWindow;
    mainWindow.show();

    return app.exec();
}
