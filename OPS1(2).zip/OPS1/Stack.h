#ifndef STACK_H
#define STACK_H

#include <stack>  
using namespace std;

class Stack {
private:
    stack<int> stackArray; 

public:
    void push(int value) { stackArray.push(value); }
    void pop() { if (!stackArray.empty()) stackArray.pop(); }
    int peek() const { return stackArray.empty() ? -1 : stackArray.top(); }
    stack<int> getStack() const { return stackArray; }  
};

#endif 

